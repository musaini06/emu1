# @author : Shadow Bot
# date : 12 Oktober 2018
# time : 13.00 WIB
# location : Indonesia

# Gunakan Dengan Baik 
# Jangan Di Perjual Belikan 
