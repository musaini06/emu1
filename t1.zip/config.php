<?php

$ticket = "sHp2r312otmCpnGns3mCqJhovNiBh3_cutORarTOgpSxfY5riZy62YLPeWGzq5NihKC324uHj9uv0HlstKWc2a2jra6KZM3XjZSKo7-Ik2ubfrCUi4RzoQ";
$meid = "f9d8c0cd9b8f3e30";
$os="android";
$sign="ea309938868bb85d77a7aabeb93abed0f6a5a74daff309075ae2e17bc79f9b5b";
