<?php
$config = [
"imei" => "864218038231638",
"sign" => 
"6431743fd66560e332c44b12d5fef62256656996",
"token" => 
"de78f52bb56e4a81587b42bd2fd15e59",
"uuid" => "fa577a60-bb6f-4826-82ae-299f53cf5e7d"
];
